// Add mode toggle UI
ColorWheel.extend('modeToggle', function (colorWheel) {
  var modeToggle = colorWheel.container.append('select')
    .attr('class', colorWheel.cx('mode-toggle'))
    .on('change', function () {
      colorWheel.currentMode = this.value;
      colorWheel.setHarmony();
    });

  for (var mode in ColorWheel.modes) {
    modeToggle.append('option').text(ColorWheel.modes[mode])
      .attr('selected', function () {
        return ColorWheel.modes[mode] == colorWheel.currentMode ? 'selected' : null;
      });
  }
});
